class CallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)

        if (stateStr == TelephonyManager.EXTRA_STATE_RINGING) {
            Log.d("CallReceiver", "Incoming call from: $incomingNumber")
        }
    }
}