class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val callButton = findViewById<Button>(R.id.callButton)
        val answerButton = findViewById<Button>(R.id.answerButton)

        callButton.setOnClickListener {
            CallUtils.makeCall(this, "1234567890")
        }

        answerButton.setOnClickListener {
            CallUtils.answerCall(this)
        }
    }
}